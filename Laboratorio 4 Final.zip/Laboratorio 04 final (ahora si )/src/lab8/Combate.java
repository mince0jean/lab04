package lab8;

public class Combate {
    private Personaje p1;
    private Personaje p2;
    
//---------------------------------------------------------------- Seleccion de personajes aleatorios  ---------------------------------------------------------    
    
    public Combate() {
         
    Personaje[] personajesDisponibles = new Personaje[]{
        new Elfo(90,16,"Elfo","Daga de las Sombras"), new Enano(100,8,"Enano","Martillo de los Profundos"),new Hombre(105,10,"Humano","Espada de la Luz")
    };


    do{
        p1 = personajesDisponibles[(int)(Math.random()* personajesDisponibles.length)];
        p2= personajesDisponibles[(int)(Math.random()* personajesDisponibles.length)];
        }while (p1==p2);
            
}
//------------------------------------------------------------------------------------------------------------------------------------------------- 
    
    
//-------------------------------------------------------------- R O N D A S ----------------------------------------------------------------------------------     
    public void iniciar(Personaje p1,Personaje p2){
        System.out.println("El combate a Comenzado");
        System.out.println("El Personaje numero 1 es: " + p1.getNombre());
        System.out.println("El Personaje numero 2 es: " + p2.getNombre());
        
        for (int i = 1 ; i<10 ; i++ ){
        
            System.out.println("Ronda (" + i +"):");
            p2.setVida(p2.getVida() - p1.getDaño());
            System.out.println("El personaje " +p1.getNombre() +"a hecho un daño de:"+ p1.getDaño());
            
            if (p1 instanceof Hombre hombre){
            hombre.setDaño(hombre.getDaño()-1);
            }
            
            if (p2.getVida() <=0){
            
                System.out.println(p2.getNombre() + " ha perdido.");
                System.out.println(p2.derrota());
                
                System.out.println("");
                
                System.out.println(p1.victoria());
                System.out.println(p1.Datos());
                return;
            }
            System.out.println("El personaje " +p2.getNombre() +"a hecho un daño de:"+ p2.getDaño());
            if (p2 instanceof Hombre hombre){
            hombre.setDaño(hombre.getDaño()-1);
            }
            
            p1.setVida(p1.getVida() - p2.getDaño());
            if (p1.getVida() <=0){
            
                System.out.println(p1.getNombre() + " ha perdido.");
                System.out.println(p1.derrota());
                
                System.out.println("");
                
                System.out.println(p2.victoria());
                System.out.println(p2.Datos());
                return;
            
            }
           System.out.println("Vida del Personaje 1 ( "+ p1.getNombre()+" ): " + p1.getVida());
           System.out.println("Vida del Personaje 2 ( "+ p2.getNombre()+" ): " + p2.getVida());
            }
            
        if (p1.getVida() > p2.getVida()){
            
            System.out.println("El ganador por tener mayor vida acabada las 10 rondas es: " + p1.getNombre());
            System.out.println(p1.Datos());
            
        }
        
        else if (p2.getVida() > p1.getVida()){
            
           System.out.println("El ganador por tener mayor vida acabada las 10 rondas es: " + p2.getNombre()); 
           System.out.println(p2.Datos()); 
           
        }
        
        else{
            
            System.out.println("No hay ganadores, despues de las 10 rondas, ambos jugadores siguen con la misma vida.");
            
        }
        
        }
    }
//------------------------------------------------------------------------------------------------------------------------------------------------- 
