package lab8;
import java.util.*;

public class Lab8 {
    
    public static void main(String[] args) {
        
        //--------------------------------------------------------??????????????''----------------------------------------------------------------------------------------- 
        Personaje [] personajesDisponibles = { new Elfo(90,18,"elfo","Daga de las Sombras"),new Enano(100,8,"Enano","Martillo de los Profundos"),new Hombre(100,10,"Humano","Espada de la Luz")}; 
        Scanner leer = new Scanner(System.in);
        
        Personaje p1,p2;
        do{
        p1 = personajesDisponibles[(int)(Math.random()* personajesDisponibles.length)];
        p2= personajesDisponibles[(int)(Math.random()* personajesDisponibles.length)];
        }while (p1==p2);
//----------------------------------------------------------------------------????????????????'---------------------------------------------------------------------         
        System.out.println("Juego de combates random");
        System.out.println("Los personajes son;\nElfo : Inicia con un 10% menos de su vida \n"
                + "Enano: Este cuenta con la habilidad aumento de vida\n"
                + "Humano: Cuenta con un super bono de daño que va perdiendo cada ronda");
        
        if (p1 instanceof Hombre hombre){
            System.out.println("Ingrese el Nombre del Personaje Hombre:");
            hombre.setNombre(leer.nextLine());
            System.out.println("Ingrese la Casta del Personaje:");
            hombre.setCasta(leer.nextLine());
            hombre.superBono(hombre);
        }
        if (p1 instanceof Enano enano){
            System.out.println("Ingrese el Nombre del Personaje tipo Enano:");
            enano.setNombre(leer.nextLine());
            System.out.println("Ingrese el Clan del Personaje:");
            enano.setClan(leer.nextLine());
            enano.aumentaVida(enano);
        }
        if (p1 instanceof Elfo elfo){
            System.out.println("Ingrese el Nombre del Elfo:");
            elfo.setNombre(leer.nextLine());
            System.out.println("Ingrese el reino del Personaje:");
            elfo.setReino(leer.nextLine());
            elfo.quitaVida(elfo);
        }
        if (p2 instanceof Hombre hombre){
            System.out.println("Ingrese el Nombre del Personaje Hombre:");
            hombre.setNombre(leer.nextLine());
            System.out.println("Ingrese la Casta del Personaje:");
            hombre.setCasta(leer.nextLine());
            hombre.superBono(hombre);
        }
        if (p2 instanceof Enano enano){
            System.out.println("Ingrese el Nombre del Personaje tipo Enano:");
            enano.setNombre(leer.nextLine());
            System.out.println("Ingrese el Clan del Personaje:");
            enano.setClan(leer.nextLine());
            enano.aumentaVida(enano);
        }
        if (p2 instanceof Elfo elfo){
            System.out.println("Ingrese el Nombre del Elfo:");
            elfo.setNombre(leer.nextLine());
            System.out.println("Ingrese el reino del Personaje:");
            elfo.setReino(leer.nextLine());
            elfo.quitaVida(elfo);
            elfo.quitaVida(elfo);
        }
        
        Combate c = new Combate();
        
        c.iniciar(p1,p2);
        
    }

}
