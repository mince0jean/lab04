
package lab8;

public abstract class Personaje {
    
 //----------------------------------------------------------- A T R I B U T O S -----------------------------------------------------------------------------------------    
    private String nombre;
    private String raza;
    private String arma;
    private int vida;
    private int daño;
    private int bonificacion;
 //-----------------------------------------------------------------------------------------------------------------------------------------------------
    
    
 //------------------------------------------------------------- C O N S T R U C T O R E S ------------------------------------------------------------//
    public Personaje(String nombre, String raza, String arma, int vida, int daño, int bonificacion) {
        this.nombre = nombre;
        this.raza = raza;
        this.arma = arma;
        this.vida = vida;
        this.daño = daño;
        this.bonificacion = bonificacion; 
    }
    
    public Personaje(int vida, int daño,String raza, String arma) {
        this.vida = vida;
        this.daño = daño;
        this.raza = raza;
        this.arma = arma;
    }
 //-----------------------------------------------------------------------------------------------------------------------------------------------------    
    
    
 //------------------------------------------------------------- G E T  A N D  S E T -------------------------------------------------------------    
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getRaza() {
        return raza;
    }
    public void setRaza(String raza) {
        this.raza = raza;
    }
    public String getArma() {
        return arma;
    }
    public void setArma(String arma) {
        this.arma = arma;
    }
    public int getVida() {
        return vida;
    }
    public void setVida(int vida) {
        this.vida = vida;
    }
    public int getDaño() {
        return daño;
    }
    public void setDaño(int daño) {
        this.daño = daño;
    }
    public int getBonificacion() {
        return bonificacion;
    }
    public void setBonificacion(int bonificacion) {
        this.bonificacion = bonificacion;
    }
     //-----------------------------------------------------------------------------------------------------------------------------------------------------
    
    
    //---------------------------------------------------------------- M E T O D O S  ---------------------------------------------------------

    
    public void Combate(){
    }
    public abstract String historia();
    public abstract String victoria();
    public abstract String derrota();

    public void MensajeInicial(){
    }
    
     public String Datos(){
        
        return "---Datos del Ganador---\n-Nombre: " + this.nombre +"         -Raza: "+ this.raza +"\n-Vida Restante: " + this.vida +"         -Daño: " + this.daño +"\n-Arma: " + this.arma +"         -Bonificacion: " + this.bonificacion;  
    }
  //-----------------------------------------------------------------------------------------------------------------------------------------------------
}
