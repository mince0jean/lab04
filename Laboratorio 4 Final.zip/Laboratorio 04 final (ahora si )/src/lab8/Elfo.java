package lab8;

public class Elfo extends Personaje{
    
    private String reino;
    
//------------------------------------------------------------- C O N S T R U C T O R E S ------------------------------------------------------------//
    
    public Elfo(int vida, int daño, String raza, String arma) {
        super(vida, daño, raza, arma);
    }
//-----------------------------------------------------------------------------------------------------------------------------------------------------

    
//------------------------------------------------------------- G E T  A N D  S E T -------------------------------------------------------------    
    public String getReino() {
        return reino;
    }

    public void setReino(String reino) {
        this.reino = reino;
    }
//-----------------------------------------------------------------------------------------------------------------------------------------------------    
    
    @Override
    public String derrota(){
    return "El elfo, cayó de rodillas, su espada se apagó y su corazón se llenó de tristeza mientras sus enemigos se alzaban victoriosos, pero juró volver más fuerte y reclamar su revancha.";}
    
    @Override
    public String victoria(){
    return "El elfo, se erguió orgulloso, su espada brillando con la luz de la victoria. Miró a su alrededor, sabiendo que su valentía y habilidad habían prevalecido, y sonrió con gratitud hacia sus aliados mientras celebraban juntos el triunfo.";
    }
    @Override
    public String historia(){
    return "En el tranquilo reino de Eldoria, un elfo vivía en armonía con la naturaleza. Pero cuando un malvado dragón negro amenazó con destruir su hogar, Arannis empuñó su espada élfica y juró proteger su tierra. Con su destreza en el combate y su magia ancestral, se embarcó en una misión para enfrentarse al dragón y salvar a su amado reino.";
    }
    
    public void quitaVida(Elfo el){
        el.setVida(el.getVida() - el.getVida()* (10/100));}   
    }
    

