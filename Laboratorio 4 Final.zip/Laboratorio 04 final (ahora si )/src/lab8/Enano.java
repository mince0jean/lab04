package lab8;
import java.util.*;

public class Enano extends Personaje{
    
    Scanner leer = new Scanner(System.in);
    
    private String clan;
    
    //------------------------------------------------------------- C O N S T R U C T O R E S ------------------------------------------------------------//
 
   
    public Enano(int vida, int daño, String raza, String arma) {
        super(vida, daño, raza, arma);
    }
    
    
    //----------------------------------------------------------------------------------------------------------------------------------------------------- 

        
    
    //------------------------------------------------------------- G E T  A N D  S E T -------------------------------------------------------------    

    public String getClan() {
        return clan;
    }

    public void setClan(String clan) {
        this.clan = clan;
    }
   //----------------------------------------------------------------------------------------------------------------------------------------------------- 
    
    
   //---------------------------------------------------------------- M E T O D O S  ---------------------------------------------------------  
    @Override
    public String derrota(){
    return "El enano, cayó de rodillas, su hacha y escudo a su lado, sintiendo la frustración de la derrota. Sin embargo, su espíritu inquebrantable no se rindió, prometiendo vengarse de sus enemigos y recuperar su honor.";}
    
    @Override
    public String victoria(){
    return "El enano se erguió, su barba ondeando con orgullo, mientras sus enemigos yacían derrotados a su alrededor. Su enfoque implacable y su coraje en la batalla habían llevado a una gloriosa victoria. Brindó con una jarra de cerveza en honor a sus compañeros caídos y a su triunfo en la batalla.";
    }
    @Override
    public String historia(){
    return "Un enano valiente y experto en la forja, se unió a un grupo de aventureros en busca de una antigua reliquia en las profundidades de las montañas. Enfrentaron trampas mortales y criaturas feroces, pero Gruffin demostró su habilidad con su hacha y su astucia para sortear los obstáculos. Finalmente, encontraron la reliquia y la devolvieron a su lugar de origen, ganándose la admiración de su clan y la fama como un verdadero héroe enano.";
    }
    

    
    public void aumentaVida(Enano e){
        int bandera;
        
        do{
            bandera = 1;
            try{
        
                do{
                System.out.println("Ingrese el valor del bono (entre el 50 y el 100):");
                e.setBonificacion(leer.nextInt());
                }while(e.getBonificacion()>100 || e.getBonificacion()<50);
                e.setVida(e.getVida()+e.getBonificacion());  
                }
            catch(InputMismatchException ex){
                
                leer.nextLine();
                System.out.println("Porfavor ingrese caracter NUMERICO entre 50 y 100:");
                bandera = 0;
                
            }
           }while(bandera == 0);
        }
     //----------------------------------------------------------------------------------------------------------------------------------------------
}
