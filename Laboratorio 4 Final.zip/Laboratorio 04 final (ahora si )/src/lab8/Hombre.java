package lab8;
import java.util.*;

public class Hombre extends Personaje {
    
    Scanner leer= new Scanner(System.in);
    private String casta;

    
 //------------------------------------------------------------- G E T  A N D  S E T -------------------------------------------------------------
    public String getCasta() {
        return casta;
    }
    public void setCasta(String casta) {
        this.casta = casta;
    }
    
 //-----------------------------------------------------------------------------------------------------------------------------------------------------
    
     
    //------------------------------------------------------------- C O N S T R U C T O R E S ------------------------------------------------------------//
    
    public Hombre(int vida, int daño, String raza, String arma) {
        super(vida, daño, raza, arma);
    }
    //-----------------------------------------------------------------------------------------------------------------------------------------------------


   
    
    
//---------------------------------------------------------------- M E T O D O S  ---------------------------------------------------------      
    @Override
    public String derrota(){
    return "El guerrero humano, cayó al suelo, agotado y herido, mientras sus enemigos se regocijaban en su derrota. Sin embargo, su determinación ardía en su interior, prometiendo levantarse nuevamente y luchar con aún más ferocidad.";}
    
    @Override
    public String victoria(){
    return "El humano rugió de triunfo mientras su espada encontraba su objetivo, derribando a su último enemigo. La batalla había sido ardua, pero su habilidad y coraje lo habían llevado a la victoria. Miró a sus compañeros, compartiendo una sonrisa de camaradería y celebrando su gloriosa conquista.";
    }
    @Override
    public String historia(){
    return "Un valiente guerrero humano, se embarcó en una búsqueda para vengar la muerte de su familia a manos de un malvado dragón. Luchó contra peligrosos monstruos y superó desafíos mortales, hasta que finalmente enfrentó al dragón en una épica batalla. Con su astucia y valentía, Roland derrotó al dragón y restauró la paz en su tierra, honrando así la memoria de su familia.";
    }
    
   
    public void superBono(Hombre h){
        int bandera;
        
        do{
            try{
                bandera = 1;
                do{    
                System.out.println("Ingrese el valor del bono (entre el 5 y el 15):");
                h.setBonificacion(leer.nextInt());
                }

                while(h.getBonificacion() > 15 || h.getBonificacion() <5);

                h.setDaño(h.getDaño()+h.getBonificacion());     
                }
            catch(InputMismatchException ex){
                leer.nextLine();
                System.out.println("Porfavor ingrese caracter NUMERICO entre 5 y 15:");
                bandera = 0;
            }
        }while(bandera == 0);
    }
        
 //----------------------------------------------------------------------------------------------------------------------------------------------   }
    
}
